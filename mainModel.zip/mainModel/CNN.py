import h5py
import numpy as np
import matplotlib.pyplot as plt
import os
os.environ['CUDA_VISIBLE_DEVICES']='2,3'

print("--------------data processing----------------")

base_dir = "data/"
path_training = os.path.join(base_dir, "training.h5")
path_validation = os.path.join(base_dir, "validation.h5")
path_test = os.path.join(base_dir, "round1_test_a_20181109.h5")

fid_training = h5py.File(path_training,'r')
fid_validation = h5py.File(path_validation,'r')
fid_test = h5py.File(path_test,'r')

print("shape for each channel.")#只有三个字典参数
s1_training = fid_training['sen1']
print(s1_training.shape)#(352366, 32, 32, 8)
s2_training = fid_training['sen2']
print(s2_training.shape)#(352366, 32, 32, 10)
label_training = fid_training['label']
print(label_training.shape)#(352366, 17)

print("-" * 60)
print("validation part")
s1_validation = fid_validation['sen1']
print(s1_validation.shape)#(24119, 32, 32, 8)
s2_validation = fid_validation['sen2']
print(s2_validation.shape)#(24119, 32, 32, 10)
label_validation = fid_validation['label']
print(label_validation.shape)#(24119, 17)

print("-" * 60)
print("test part")
s1_test = fid_test['sen1']
print(s1_test.shape)#(4838, 32, 32, 8)
s2_test = fid_test['sen2']
print(s2_test.shape)#(4838, 32, 32, 10)

print("show class distribution")
label_qty = np.sum(fid_training["label"], axis=0)  # compute the quantity for each col
print(label_qty)   #统计类分布情况   每一类中的统计数据

label_qty_val = np.sum(fid_validation["label"], axis=0)
print (label_qty_val)

train_s2 = np.array(fid_training['sen2'])
train_label = np.array(fid_training['label'])
validation_s2 = np.array(fid_validation['sen2'])
validation_label = np.array(fid_validation['label'])

train_data = np.vstack([train_s2, validation_s2])
train_label = np.vstack([train_label, validation_label])

x_test = np.array(fid_test['sen2'])

from sklearn.model_selection import train_test_split
x_train, x_val, y_train, y_val = train_test_split(train_data, train_label,
        test_size=0.2, shuffle=True, stratify=train_label)

print("-" * 60)
print("build and train the model")
from keras import models
from keras import layers
from keras.layers import Dense,Convolution2D,Activation,MaxPooling2D,Dropout,Flatten,Conv2D,BatchNormalization
from keras.callbacks import ModelCheckpoint, ReduceLROnPlateau, EarlyStopping
from keras.utils import multi_gpu_model
from keras import regularizers
from keras.initializers import RandomNormal
from keras.optimizers import RMSprop,SGD
"""model"""
def build_model():

    model = models.Sequential()
    weight_decay = 0.001

    model.add(Conv2D(64, (3, 3), padding='same',
                     input_shape=[32,32,10],kernel_initializer= RandomNormal(mean=0.0, stddev=0.01),kernel_regularizer=regularizers.l2(weight_decay)))  #no same
    model.add(Activation('relu'))
    model.add(BatchNormalization())

    model.add(Conv2D(96, (3, 3), padding='same', kernel_initializer=RandomNormal(mean=0.0, stddev=0.01),
                     kernel_regularizer=regularizers.l2(weight_decay)))
    model.add(Activation('relu'))
    model.add(BatchNormalization())
    model.add(Conv2D(96, (3, 3), padding='same',kernel_initializer= RandomNormal(mean=0.0, stddev=0.01), kernel_regularizer=regularizers.l2(weight_decay)))
    model.add(Activation('relu'))
    model.add(BatchNormalization())


    model.add(Conv2D(128, (3, 3), padding='same',kernel_initializer= RandomNormal(mean=0.0, stddev=0.01), kernel_regularizer=regularizers.l2(weight_decay)))
    model.add(Activation('relu'))
    model.add(BatchNormalization())
    model.add(Conv2D(128, (3, 3), padding='same', kernel_initializer=RandomNormal(mean=0.0, stddev=0.01),
                     kernel_regularizer=regularizers.l2(weight_decay)))
    model.add(Activation('relu'))
    model.add(BatchNormalization())
    model.add(Conv2D(128, (3, 3), padding='same', kernel_initializer=RandomNormal(mean=0.0, stddev=0.01),
                     kernel_regularizer=regularizers.l2(weight_decay)))
    model.add(Activation('relu'))
    model.add(BatchNormalization())

    model.add(Conv2D(192, (3, 3), padding='same',kernel_initializer= RandomNormal(mean=0.0, stddev=0.01), kernel_regularizer=regularizers.l2(weight_decay)))
    model.add(Activation('relu'))
    model.add(BatchNormalization())
    model.add(Conv2D(192, (3, 3), padding='same', kernel_initializer=RandomNormal(mean=0.0, stddev=0.01),
                     kernel_regularizer=regularizers.l2(weight_decay)))
    model.add(Activation('relu'))
    model.add(BatchNormalization())
    model.add(Conv2D(192, (3, 3), padding='same',kernel_initializer= RandomNormal(mean=0.0, stddev=0.01), kernel_regularizer=regularizers.l2(weight_decay)))
    model.add(Activation('relu'))
    model.add(BatchNormalization())

    model.add(Conv2D(256, (3, 3), padding='same', kernel_initializer=RandomNormal(mean=0.0, stddev=0.01),
                     kernel_regularizer=regularizers.l2(weight_decay)))
    model.add(Activation('relu'))
    model.add(BatchNormalization())
    model.add(Conv2D(256, (3, 3), padding='same',kernel_initializer= RandomNormal(mean=0.0, stddev=0.01), kernel_regularizer=regularizers.l2(weight_decay)))
    model.add(Activation('relu'))
    model.add(BatchNormalization())

    model.add(Conv2D(512, (3, 3), padding='same', kernel_initializer=RandomNormal(mean=0.0, stddev=0.01),
                     kernel_regularizer=regularizers.l2(weight_decay)))
    model.add(Activation('relu'))
    model.add(BatchNormalization())

    model.add(Flatten())
    model.add(Dense(512,kernel_initializer= RandomNormal(mean=0.0, stddev=0.01), kernel_regularizer=regularizers.l2(weight_decay)))
    model.add(Activation('relu'))
    model.add(Dropout(0.5))
    model.add(Dense(128,kernel_initializer= RandomNormal(mean=0.0, stddev=0.01), kernel_regularizer=regularizers.l2(weight_decay)))
    model.add(Activation('relu'))

    model.add(Dropout(0.5))
    model.add(Dense(17))
    model.add(Activation('softmax'))
    return model

model = build_model()
model.summary()
model = multi_gpu_model(model, gpus=2)  #add

rmsprop = RMSprop(lr=0.0001)
model.compile(optimizer=rmsprop,loss='categorical_crossentropy',metrics=['accuracy'])
checkpoint = ModelCheckpoint('epochCNN7best.h5',
                             monitor='val_acc', save_weights_only= True, save_best_only=True, verbose=1,period=5)
reduce_lr = ReduceLROnPlateau(monitor='val_acc', factor=0.5, patience=3, verbose=1)
early_stopping = EarlyStopping(monitor='val_acc', min_delta=0, patience=10, verbose=1)

model.fit(x_train,y_train,epochs=150,batch_size=128,shuffle=True,
          validation_data=(x_val, y_val),callbacks=[checkpoint,reduce_lr,early_stopping],verbose=1)
# """output"""
# pred = model.predict(x_test)
# pred_index = np.argmax(pred, axis=1)
#
# from keras.utils import to_categorical
# pred = to_categorical(pred_index).astype(int)
# import pandas as pd
#
# data = pd.DataFrame(pred)
# data.to_csv('output_NEWcnn.csv',header=False,index=False)