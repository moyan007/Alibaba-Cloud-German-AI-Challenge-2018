import h5py
import numpy as np
import matplotlib.pyplot as plt
import os
os.environ['CUDA_VISIBLE_DEVICES']='2,3'

base_dir = "data/"
path_training = os.path.join(base_dir, "training.h5")
path_validation = os.path.join(base_dir, "validation.h5")
path_test = os.path.join(base_dir, "round2_test_a_20190121.h5")

fid_training = h5py.File(path_training,'r')
fid_validation = h5py.File(path_validation,'r')
fid_test = h5py.File(path_test,'r')

print("shape for each channel.")#只有三个字典参数
s1_training = fid_training['sen1']
print(s1_training.shape)#(352366, 32, 32, 8)
s2_training = fid_training['sen2']
print(s2_training.shape)#(352366, 32, 32, 10)
label_training = fid_training['label']
print(label_training.shape)#(352366, 17)

print("-" * 60)
print("validation part")
s1_validation = fid_validation['sen1']
print(s1_validation.shape)#(24119, 32, 32, 8)
s2_validation = fid_validation['sen2']
print(s2_validation.shape)#(24119, 32, 32, 10)
label_validation = fid_validation['label']
print(label_validation.shape)#(24119, 17)

print("-" * 60)
print("test part")
s1_test = fid_test['sen1']
print(s1_test.shape)#(4838, 32, 32, 8)
s2_test = fid_test['sen2']
print(s2_test.shape)#(4838, 32, 32, 10)

"""data processing"""
print("-" * 60)
print(" data pre-processing part")

# train_s2 = np.array(fid_training['sen2'])
# train_label = np.array(fid_training['label'])
#
# validation_s2 = np.array(fid_validation['sen2'])
# validation_label = np.array(fid_validation['label'])
#
# train_data = np.vstack([train_s2, validation_s2])
# train_label = np.vstack([train_label, validation_label])

x_test = np.array(fid_test['sen2'])

# from sklearn.model_selection import train_test_split
# x_train, x_val, y_train, y_val = train_test_split(train_data, train_label,
#         test_size=0.2, shuffle=True, stratify=train_label)

print("-" * 60)
print(" build and train the model")
from keras.models import Model
from keras.layers import Input, Dense, BatchNormalization, Conv2D, Activation
from keras.layers import add, Flatten, Dropout
from keras.optimizers import RMSprop,Adam
from keras.utils import multi_gpu_model
from keras.initializers import RandomNormal
from keras import regularizers
from keras.callbacks import ReduceLROnPlateau, ModelCheckpoint, EarlyStopping
from keras import models
seed = 7
np.random.seed(seed)

def Conv2d_BN(x, nb_filter, kernel_size, strides=(1, 1), padding='same', name=None):
    if name is not None:
        bn_name = name + '_bn'
        conv_name = name + '_conv'
    else:
        bn_name = None
        conv_name = None

    x = Conv2D(nb_filter, kernel_size, padding=padding,kernel_initializer=RandomNormal(mean=0.0, stddev=0.01),
               kernel_regularizer=regularizers.l2(0.01),strides=strides, activation='relu', name=conv_name)(x)
    x = BatchNormalization(name=bn_name)(x)
    return x


def Conv_Block(inpt, nb_filter, kernel_size, strides=(1, 1), with_conv_shortcut=False):
    x = Conv2d_BN(inpt, nb_filter=nb_filter[0], kernel_size=(1, 1), strides=strides, padding='same')
    x = Conv2d_BN(x, nb_filter=nb_filter[1], kernel_size=(3, 3), padding='same')
    x = Conv2d_BN(x, nb_filter=nb_filter[2], kernel_size=(1, 1), padding='same')
    if with_conv_shortcut:
        shortcut = Conv2d_BN(inpt, nb_filter=nb_filter[2], strides=strides, kernel_size=kernel_size)
        x = add([x, shortcut])
        return x
    else:
        x = add([x, inpt])
        return x


inpt = Input(shape=(32, 32, 10))

x = Conv2d_BN(inpt, nb_filter=96, kernel_size=(3, 3), strides=(1, 1), padding='same')

x = Conv_Block(x, nb_filter=[64, 64, 128], kernel_size=(3, 3), strides=(1, 1), with_conv_shortcut=True)
x = Conv_Block(x, nb_filter=[64, 64, 128], kernel_size=(3, 3))
x = Conv_Block(x, nb_filter=[64, 64, 128], kernel_size=(3, 3))

x = Conv_Block(x, nb_filter=[96, 96, 160], kernel_size=(3, 3), strides=(1, 1), with_conv_shortcut=True)
x = Conv_Block(x, nb_filter=[96, 96, 160], kernel_size=(3, 3))
x = Conv_Block(x, nb_filter=[96, 96, 160], kernel_size=(3, 3))
x = Conv_Block(x, nb_filter=[96, 96, 160], kernel_size=(3, 3))
x = Conv_Block(x, nb_filter=[96, 96, 160], kernel_size=(3, 3))
# x = Conv_Block(x, nb_filter=[96, 96, 160], kernel_size=(3, 3))

x = Conv_Block(x, nb_filter=[112, 112, 192], kernel_size=(3, 3), strides=(1, 1), with_conv_shortcut=True)
x = Conv_Block(x, nb_filter=[112, 112, 192], kernel_size=(3, 3))
x = Conv_Block(x, nb_filter=[112, 112, 192], kernel_size=(3, 3))
x = Conv_Block(x, nb_filter=[112, 112, 192], kernel_size=(3, 3))
x = Conv_Block(x, nb_filter=[112, 112, 192], kernel_size=(3, 3))
# x = Conv_Block(x, nb_filter=[112, 112, 192], kernel_size=(3, 3))

x = Conv_Block(x, nb_filter=[128, 128, 224], kernel_size=(3, 3), strides=(1, 1), with_conv_shortcut=True)
x = Conv_Block(x, nb_filter=[128, 128, 224], kernel_size=(3, 3))
x = Conv_Block(x, nb_filter=[128, 128, 224], kernel_size=(3, 3))

x = Flatten()(x)
x = Dense(512, kernel_initializer=RandomNormal(mean=0.0, stddev=0.01), kernel_regularizer=regularizers.l2(0.01),
          activation='relu')(x)
x = Dropout(0.5)(x)
x = Dense(128, kernel_initializer=RandomNormal(mean=0.0, stddev=0.01), kernel_regularizer=regularizers.l2(0.01),
          activation='relu')(x)
x = Dropout(0.5)(x)
x = Dense(17, activation='softmax')(x)

model = Model(inputs=inpt, outputs=x)
model = multi_gpu_model(model, gpus=2)  #add

# checkpoint = ModelCheckpoint('epochResnet50_adam128_l20001.h5',
#                              monitor='val_acc', save_weights_only= True, save_best_only=True, verbose=1,period=5)
# reduce_lr = ReduceLROnPlateau(monitor='val_acc', factor=0.5,  patience=3, verbose=1)#,min_lr= 1e-8,
# early_stopping = EarlyStopping(monitor='val_acc', min_delta=0, patience=10, verbose=1)
#
# model.compile(loss='categorical_crossentropy', optimizer=Adam(lr=0.0001), metrics=['accuracy'])
model.summary()
model.load_weights('epochResnet50_adam128_l20001.h5')
# model.fit(x_train,y_train,epochs=150,batch_size=128,shuffle=True,validation_data=(x_val, y_val),
#           callbacks=[checkpoint,reduce_lr,early_stopping],verbose=1)

"""output"""
pred = model.predict(x_test)


pred_index = np.argmax(pred, axis=1)

from keras.utils import to_categorical
pred = to_categorical(pred_index).astype(int)
import pandas as pd

data = pd.DataFrame(pred)
data.to_csv('output/output_1model_resnet50Adam128Regular.csv',header=False,index=False)

"""后面进一步的工作可以考虑多个模型融合 融合sen1和sen2的预测结果"""