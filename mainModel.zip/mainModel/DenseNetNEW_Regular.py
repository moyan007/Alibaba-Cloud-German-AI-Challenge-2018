from keras.models import Model
from keras.layers.core import Dense, Dropout, Activation
from keras.layers.convolutional import Convolution2D
from keras.layers.pooling import AveragePooling2D
from keras.layers.pooling import GlobalAveragePooling2D
from keras.layers import Input, Flatten ,Conv2D ,add
from keras.layers.merge import Concatenate
from keras.layers.normalization import BatchNormalization
from keras.regularizers import l2
import keras.backend as K
from keras import regularizers
from keras import models
from keras.initializers import RandomNormal
#卷积块
def conv_block(input, nb_filter, dropout_rate=None, weight_decay=0.01):

    x = Convolution2D(nb_filter, (3, 3), kernel_initializer=RandomNormal(mean=0.0, stddev=0.01), padding="same",
                      kernel_regularizer=l2(weight_decay))(input)
    x = Activation('relu')(x)
    x = BatchNormalization()(x)
    if dropout_rate is not None:
        x = Dropout(dropout_rate)(x)

    return x
#trans块
def transition_block(input, nb_filter, dropout_rate=None, weight_decay=0.01):

    x = Convolution2D(nb_filter, (1, 1), kernel_initializer=RandomNormal(mean=0.0, stddev=0.01), padding="same",
                      kernel_regularizer=l2(weight_decay))(input)
    x = Activation('relu')(x)
    if dropout_rate is not None:
        x = Dropout(dropout_rate)(x)

    x = BatchNormalization()(x)

    return x
# dense块
def dense_block(x, nb_layers, nb_filter, growth_rate, dropout_rate=None, weight_decay=0.01):

    concat_axis = 3

    feature_list = [x]

    for i in range(nb_layers):
        x = conv_block(x, growth_rate, dropout_rate, weight_decay)
        feature_list.append(x)
        x = Concatenate(axis=concat_axis)(feature_list)
        nb_filter += growth_rate

    return x, nb_filter

def createDenseNet(img_dim, depth=40, nb_dense_block=2, growth_rate=16, nb_filter=32, dropout_rate=None,
                     weight_decay=0.01, verbose=True): #3 12 32

    model_input = Input(shape=img_dim)

    assert (depth - 4) % 3 == 0, "Depth must be 3 N + 4"

    # layers in each dense block
    nb_layers = int((depth - 4) / 3)

    # Initial convolution
    x = Convolution2D(nb_filter, (3, 3), kernel_initializer=RandomNormal(mean=0.0, stddev=0.01), padding="same",
                      name="initial_conv2D", kernel_regularizer=l2(weight_decay))(model_input)
    x = Activation('relu')(x)
    x = BatchNormalization()(x)

    # Add dense blocks
    for block_idx in range(nb_dense_block - 1):
        x, nb_filter = dense_block(x, nb_layers, nb_filter, growth_rate, dropout_rate=dropout_rate,
                                   weight_decay=weight_decay)
        # add transition_block
        x = transition_block(x, nb_filter, dropout_rate=dropout_rate, weight_decay=weight_decay)

    # The last dense_block does not have a transition_block
    x, nb_filter = dense_block(x, nb_layers, nb_filter, growth_rate, dropout_rate=dropout_rate,
                               weight_decay=weight_decay)


    x = Flatten()(x)
    x = Dense(512, kernel_initializer=RandomNormal(mean=0.0, stddev=0.01), kernel_regularizer=l2(weight_decay),
              activation='relu')(x)
    x = Dropout(0.5)(x)
    x = Dense(128, kernel_initializer=RandomNormal(mean=0.0, stddev=0.01), kernel_regularizer=l2(weight_decay),
              activation='relu')(x)
    x = Dropout(0.5)(x)
    x = Dense(17, activation='softmax')(x)
    densenet = Model(inputs=model_input, outputs=x)

    if verbose:
        print("DenseNet-%d-%d created." % (depth, growth_rate))

    return densenet


import h5py
import numpy as np
import matplotlib.pyplot as plt
import os
os.environ['CUDA_VISIBLE_DEVICES']='2,3'

base_dir = "data/"
path_training = os.path.join(base_dir, "training.h5")
path_validation = os.path.join(base_dir, "validation.h5")
path_test = os.path.join(base_dir, "round1_test_b_20190104.h5")

fid_training = h5py.File(path_training,'r')
fid_validation = h5py.File(path_validation,'r')
fid_test = h5py.File(path_test,'r')

print("shape for each channel.")#只有三个字典参数
s1_training = fid_training['sen1']
print(s1_training.shape)#(352366, 32, 32, 8)
s2_training = fid_training['sen2']
print(s2_training.shape)#(352366, 32, 32, 10)
label_training = fid_training['label']
print(label_training.shape)#(352366, 17)

print("-" * 60)
print("validation part")
s1_validation = fid_validation['sen1']
print(s1_validation.shape)#(24119, 32, 32, 8)
s2_validation = fid_validation['sen2']
print(s2_validation.shape)#(24119, 32, 32, 10)
label_validation = fid_validation['label']
print(label_validation.shape)#(24119, 17)

print("-" * 60)
print("test part")
s1_test = fid_test['sen1']
print(s1_test.shape)#(4838, 32, 32, 8)
s2_test = fid_test['sen2']
print(s2_test.shape)#(4838, 32, 32, 10)

"""data processing"""
print("-" * 60)
print(" data pre-processing part")

train_s2 = np.array(fid_training['sen2'])
train_label = np.array(fid_training['label'])

validation_s2 = np.array(fid_validation['sen2'])
validation_label = np.array(fid_validation['label'])

train_data = np.vstack([train_s2, validation_s2])
train_label = np.vstack([train_label, validation_label])

x_test = np.array(fid_test['sen2'])

from sklearn.model_selection import train_test_split
x_train, x_val, y_train, y_val = train_test_split(train_data, train_label,
        test_size=0.2, shuffle=True, stratify=train_label)

print("-" * 60)
print(" build and train the model")
from keras.utils import multi_gpu_model
from keras.optimizers import Adam, RMSprop
from keras.callbacks import ReduceLROnPlateau, ModelCheckpoint, EarlyStopping

checkpoint = ModelCheckpoint('epochDensenet_adam128_lr001.h5',
                             monitor='val_acc', save_weights_only= True, save_best_only=True, verbose=1,period=5)
reduce_lr = ReduceLROnPlateau(monitor='val_acc', factor=0.5, patience=3,verbose=1)#, min_lr= 1e-8
early_stopping = EarlyStopping(monitor='val_acc', min_delta=0, patience=10, verbose=1)

optimizer = Adam(lr=0.0001)
model = createDenseNet(img_dim=(32,32,10), depth=40,
                       growth_rate=16)
model = multi_gpu_model(model, gpus=2)  #add
model.compile(loss='categorical_crossentropy', optimizer=optimizer, metrics=['accuracy'])

model.summary()
model.fit(x_train,y_train,epochs=150,batch_size=128,shuffle=True,validation_data=(x_val, y_val),
          callbacks=[checkpoint,reduce_lr,early_stopping],verbose=1)

